import "./styles.css";

class Flore {
  constructor(famille) {
    this.famille = famille;
  }
  toString() {
    return " Famille des " + this.famille;
  }
}

class Arbre extends Flore {
  constructor(famille, type) {
    super(famille);
    this.type = type;
  }

  toString() {
    return "C'est un arbre " + this.type + super.toString();
  }
}

class Pommier extends Arbre {
  constructor(famille, type) {
    super(famille, type);
    this.nbMoyen = 40;
  }

  toString() {
    return (
      "Le pommier contient en moyenne " +
      this.nbMoyen +
      "pommes. " +
      super.toString()
    );
  }
}

var pommier = new Pommier("Rosacées", "fruitier");

console.log(pommier.toString());

class Piscine {
  constructor(longueur, largeur, hauteur, debit) {
    this.longueur = longueur;
    this.largeur = largeur;
    this.hauteur = hauteur;
    this.debit = debit;
  }

  remplissage() {
    let tempsHeure = (this.longueur * this.largeur * this.hauteur) / this.debit;
    return tempsHeure * 60;
  }
}

var piscine = new Piscine(5, 10, 10, 50);
console.log(piscine.remplissage());
