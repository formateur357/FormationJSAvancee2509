const message = 'Hello world' 

function searchPokemon(id){
  let pokemonId = document.getElementById("pokemonIdInput").value;
  fetch("https://pokeapi.co/api/v2/pokemon/" + pokemonId,{
    method: 'GET',
    headers: {
        'Accept': 'application/json',
    },
})
  .then(response => response.json())
  .then((data) => {
    console.log(data.species.name);
  })
  .catch(error => console.log(error))
}

// Log to console
console.log(message)